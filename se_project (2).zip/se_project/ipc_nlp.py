import json
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from googletrans import Translator

# -------------------------------
# Load IPC Dataset
# -------------------------------
with open(r"C:\Users\Vedha Pranava\Desktop\se_project\cleaned_ipc_1000.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Filter valid entries
required_keys = {"section", "title", "description", "punishment"}
filtered_data = [entry for entry in data if required_keys.issubset(entry)]
df = pd.DataFrame(filtered_data)
df['search_text'] = df['title'] + " - " + df['description']

# -------------------------------
# Load Model & Generate Embeddings
# -------------------------------
print("✅ Generating sentence embeddings for IPC data...")
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(df['search_text'].tolist(), show_progress_bar=True)
df['embedding'] = embeddings.tolist()
embedding_matrix = np.array(df['embedding'].tolist())

# -------------------------------
# Google Translate Setup
# -------------------------------
translator = Translator()

def translate_to_english(text):
    try:
        result = translator.translate(text, dest='en')
        return result.text
    except Exception as e:
        print(f"Translation error: {e}")
        return text  # fallback to original

# -------------------------------
# Legal Advice Generator
# -------------------------------
def get_legal_tip(title):
    title = title.lower()
    if "robbery" in title or "theft" in title:
        return "Secure your belongings. Collect CCTV footage or witnesses."
    elif "assault" in title or "hurt" in title:
        return "Seek medical help and document injuries for legal action."
    elif "harassment" in title or "molestation" in title:
        return "Talk to someone you trust. Preserve any proof or messages."
    elif "cyber" in title or "privacy" in title or "identity" in title:
        return "Report the incident at the cyber crime portal or nearest cyber cell."
    elif "cheating" in title or "fraud" in title or "forgery" in title:
        return "Gather all relevant evidence and file a police complaint immediately."
    elif "murder" in title or "homicide" in title:
        return "Contact police immediately. Do not tamper with any evidence."
    elif "rape" in title or "sexual" in title:
        return "Reach out to the police or women helpline immediately. Medical assistance is also important."
    elif "trespass" in title or "mischief" in title:
        return "Gather witnesses or camera footage and file a complaint."
    elif "defamation" in title:
        return "Collect copies of statements made. You can file both civil and criminal complaints."
    return "Preserve all evidence and report to your nearest police station."

# -------------------------------
# IPC Matching Function
# -------------------------------
def find_best_ipc(complaint_text, threshold=0.5):
    if not complaint_text.strip():
        return {"error": "Complaint text is empty."}

    # Translate input to English
    translated_text = translate_to_english(complaint_text)

    # Encode and compare
    complaint_embedding = model.encode([translated_text])
    similarities = cosine_similarity(complaint_embedding, embedding_matrix)

    best_idx = int(np.argmax(similarities))
    best_score = float(similarities[0][best_idx])
    best_match = df.iloc[best_idx]

    if best_score < threshold:
        return {
            "section": best_match["section"],
            "title": best_match["title"] + " ⚠️ (Low Confidence Match)",
            "description": best_match["description"],
            "punishment": best_match["punishment"] or "Not specified",
            "tip": "This is the closest match, but confidence is low. Try describing your complaint more clearly.",
            "score": round(best_score, 4)
        }

    return {
        "section": best_match["section"],
        "title": best_match["title"],
        "description": best_match["description"],
        "punishment": best_match["punishment"] or "Not specified",
        "tip": get_legal_tip(best_match["title"]),
        "score": round(best_score, 4)
    }

# -------------------------------
# Optional Test Case
# -------------------------------
if __name__ == "__main__":
    complaint = "मेरे पड़ोसी ने मेरी छवि खराब करने के लिए झूठे आरोप लगाए।"
    print("\n🔍 Translated Complaint Match:")
    result = find_best_ipc(complaint)
    for k, v in result.items():
        print(f"{k.capitalize()}: {v}")
