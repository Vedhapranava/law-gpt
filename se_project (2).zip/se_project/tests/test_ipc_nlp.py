import unittest
from ipc_nlp import find_best_ipc, get_legal_tip

class TestIPCNLP(unittest.TestCase):

    def test_find_best_ipc_robbery(self):
        result = find_best_ipc("My phone was stolen near the market.")
        self.assertIn("theft", result['title'].lower())
        self.assertGreater(result['score'], 0.4)

    def test_find_best_ipc_assault(self):
        result = find_best_ipc("Someone hit me on the head with a stick.")
        self.assertIn("hurt", result['title'].lower())

    def test_legal_tip(self):
        tip = get_legal_tip("Theft and Robbery")
        self.assertTrue("secure your belongings" in tip.lower())

    def test_default_tip(self):
        tip = get_legal_tip("Unusual case")
        self.assertTrue("stay calm" in tip.lower())

if __name__ == '__main__':
    unittest.main()
