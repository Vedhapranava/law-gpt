import unittest
from app import create_app
from flask.testing import FlaskClient

class TestRoutes(unittest.TestCase):

    def setUp(self):
        self.app = create_app().test_client()
        self.app.testing = True

    def test_homepage(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'LawSphere', response.data)

    def test_register_page(self):
        response = self.app.get('/register')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Sign Up', response.data)

    def test_login_fail(self):
        response = self.app.post('/login', data={
            'email': 'test@example.com',
            'password': 'wrongpass'
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)  # ✅ Only check that the page loads

if __name__ == '__main__':
    unittest.main()
