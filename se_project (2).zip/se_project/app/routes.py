from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file, current_app
from flask_login import login_user, current_user, logout_user, login_required
from app.forms import RegistrationForm, LoginForm, LawyerRegistrationForm
from app.models import User, Complaint, Lawyer, ContactMessage
from app import db, bcrypt
from docx import Document
import os
from datetime import datetime
from ipc_nlp import find_best_ipc

main = Blueprint('main', __name__)

# -------------------- Context Processor for Navbar --------------------
@main.app_context_processor
def inject_user_role():
    if current_user.is_authenticated:
        lawyer = Lawyer.query.filter_by(email=current_user.email, status="Approved").first()
        return dict(is_lawyer=lawyer is not None)
    return dict(is_lawyer=False)

# -------------------- Home --------------------
@main.route('/')
@main.route('/home')
@login_required
def home():
    return render_template('home.html', title='Home')

# -------------------- Register --------------------
@main.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    form = RegistrationForm()
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data).first():
            flash('⚠️ Email already registered.', 'warning')
            return redirect(url_for('main.register'))
        if User.query.filter_by(username=form.username.data).first():
            flash('⚠️ Username already taken.', 'warning')
            return redirect(url_for('main.register'))
        if User.query.filter_by(aadhaar=form.aadhaar.data).first():
            flash('⚠️ Aadhaar already registered.', 'warning')
            return redirect(url_for('main.register'))

        hashed_pw = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(
            username=form.username.data,
            email=form.email.data,
            aadhaar=form.aadhaar.data,
            pincode=form.pincode.data,
            state=form.state.data,
            district=form.state.data,
            password=hashed_pw
        )
        db.session.add(user)
        db.session.commit()
        flash('✅ Registration successful!', 'success')
        return redirect(url_for('main.login'))

    return render_template('register.html', title='Register', form=form)

# -------------------- Login --------------------
@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user)
            flash(f'👋 Welcome back, {user.username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('main.home'))
        else:
            flash('❌ Invalid credentials.', 'danger')

    return render_template('login.html', title='Login', form=form)

# -------------------- Logout --------------------
@main.route('/logout')
@login_required
def logout():
    logout_user()
    flash('🔒 Logged out successfully.', 'info')
    return redirect(url_for('main.login'))

# -------------------- Complaint Page --------------------
@main.route('/complain', methods=['GET', 'POST'])
@login_required
def complain():
    result = None
    complaint = ""

    if request.method == 'POST':
        complaint = request.form['complaint']
        best_match = find_best_ipc(complaint)
        result = [best_match]

        if request.form.get('action') == 'generate':
            doc = Document()
            doc.add_heading('Filing of Legal Complaint', 0)
            doc.add_paragraph(f"To,\nThe Station House Officer\n{current_user.district} Police Station\n")
            doc.add_paragraph(f"Subject: Complaint under Section {best_match['section']} - {best_match['title']}")
            doc.add_paragraph("Respected Sir/Madam,")
            doc.add_paragraph(
                f"I, {current_user.username}, resident of {current_user.district}, am filing this complaint regarding:\n\n"
                f"\"{complaint}\"\n\n"
                f"This falls under Section {best_match['section']} of IPC titled '{best_match['title']}'.\n\n"
                f"Description: {best_match['description']}\n\n"
                f"Punishment: {best_match['punishment']}\n\n"
                f"Legal Guidance: {best_match['tip']}\n\n"
                f"I kindly request that appropriate legal action be initiated.\n\n"
                f"Thanking you,\n\n{current_user.username}\nAadhaar: {current_user.aadhaar}"
            )

            filename = f"{current_user.username}_{int(datetime.utcnow().timestamp())}.docx"
            folder_path = os.path.join(current_app.root_path, 'static', 'complaints')
            os.makedirs(folder_path, exist_ok=True)
            full_path = os.path.join(folder_path, filename)
            doc.save(full_path)

            complaint_record = Complaint(
                user_id=current_user.id,
                complaint_text=complaint,
                ipc_section=best_match['section'],
                ipc_title=best_match['title'],
                punishment=best_match['punishment'],
                doc_path=f"complaints/{filename}"
            )
            db.session.add(complaint_record)
            db.session.commit()

            return send_file(full_path, as_attachment=True)

    return render_template('complain.html', title="Complain", result=result, complaint=complaint)

# -------------------- Track My Case --------------------
@main.route('/track')
@login_required
def track():
    complaints = Complaint.query.filter_by(user_id=current_user.id).order_by(Complaint.date.desc()).all()
    return render_template("track.html", title="Track My Case", complaints=complaints)

# -------------------- Join as Lawyer --------------------
@main.route('/join-lawyer', methods=['GET', 'POST'])
@login_required
def join_lawyer():
    form = LawyerRegistrationForm()

    if form.validate_on_submit():
        if Lawyer.query.filter_by(email=form.email.data).first():
            flash('⚠️ Email already registered as lawyer.', 'warning')
            return redirect(url_for('main.join_lawyer'))

        if Lawyer.query.filter_by(bar_id=form.bar_id.data).first():
            flash('⚠️ This Bar Council ID is already registered.', 'warning')
            return redirect(url_for('main.join_lawyer'))

        lawyer = Lawyer(
            name=form.name.data,
            email=form.email.data,
            bar_id=form.bar_id.data,
            experience=form.experience.data,
            specialization=form.specialization.data
        )
        db.session.add(lawyer)
        db.session.commit()
        flash('✅ Application submitted successfully! You will be contacted shortly.', 'success')
        return redirect(url_for('main.home'))

    if current_user.is_authenticated:
        form.name.data = current_user.username
        form.email.data = current_user.email

    return render_template('join_lawyer.html', form=form, title='Join as Lawyer')

# -------------------- View All Approved Lawyers --------------------
@main.route('/lawyers')
def lawyers():
    all_lawyers = Lawyer.query.filter_by(status="Approved").all()
    return render_template("lawyer.html", title="Available Lawyers", lawyers=all_lawyers)

# -------------------- Contact a Lawyer --------------------
@main.route('/contact-lawyer/<int:lawyer_id>', methods=['POST'])
@login_required
def contact_lawyer(lawyer_id):
    lawyer = Lawyer.query.get_or_404(lawyer_id)

    new_message = ContactMessage(
        lawyer_id=lawyer.id,
        user_id=current_user.id
    )
    db.session.add(new_message)
    db.session.commit()

    flash(f'📩 Contact request sent to {lawyer.name}.', 'success')
    return redirect(url_for('main.lawyers'))

# -------------------- Lawyer Dashboard --------------------
@main.route('/lawyer-dashboard')
@login_required
def lawyer_dashboard():
    lawyer = Lawyer.query.filter_by(email=current_user.email, status="Approved").first()
    if not lawyer:
        flash("Access denied. You are not a registered or approved lawyer.", "danger")
        return redirect(url_for("main.home"))

    messages = ContactMessage.query.filter_by(lawyer_id=lawyer.id).order_by(ContactMessage.timestamp.desc()).all()
    return render_template("lawyer_dashboard.html", messages=messages)

# -------------------- Admin Routes --------------------
@main.route('/admin/approve-lawyer/<int:id>')
def approve_lawyer(id):
    lawyer = Lawyer.query.get_or_404(id)
    lawyer.status = "Approved"
    db.session.commit()
    return f"{lawyer.name} has been approved successfully!"

@main.route('/admin/list-lawyers')
def list_lawyers():
    lawyers = Lawyer.query.all()
    return "<br>".join([f"ID: {l.id}, Name: {l.name}, Status: {l.status}" for l in lawyers])

# -------------------- Blog Routes --------------------
@main.route('/blog/<slug>')
def blog(slug):
    blog_templates = {
        'bail-rights': 'blogs/bail_rights.html',
        'cyber-crime': 'blogs/cyber_crime.html',
        'police-complaint': 'blogs/police_complaint.html'
    }
    template = blog_templates.get(slug)
    if template:
        return render_template(template, title=slug.replace('-', ' ').title())
    flash("Blog not found.", "warning")
    return redirect(url_for('main.home'))

# -------------------- Static Info Pages --------------------
@main.route('/faq')
def faq():
    return render_template("faq.html", title="FAQ")

@main.route('/about/team')
def team():
    return render_template("team.html", title="Our Team")

@main.route('/about/mission')
def mission():
    return render_template("mission.html", title="Our Mission")

@main.route('/about/vision')
def vision():
    return render_template("vision.html", title="Our Vision")
from flask import render_template
from app import app
