from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_migrate import Migrate

# Initialize extensions
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
migrate = Migrate()

# Configure login behavior
login_manager.login_view = 'main.login'  # Redirect to login if not authenticated
login_manager.login_message_category = 'info'  # Bootstrap alert class for flash

def create_app():
    app = Flask(__name__)

    # 🔐 App Configuration
    app.config['SECRET_KEY'] = 'secretkey123'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'

    # 🔄 Initialize Extensions
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    # 🔗 Register Blueprints
    from app.routes import main
    app.register_blueprint(main)  # Make sure no url_prefix is added if you want clean URLs

    return app
