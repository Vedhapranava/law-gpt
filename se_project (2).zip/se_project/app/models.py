from app import db, login_manager
from flask_login import UserMixin
from datetime import datetime

# ---------------------------
# Flask-Login user loader
# ---------------------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------------------------
# User Model
# ---------------------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    aadhaar = db.Column(db.String(12), unique=True, nullable=False)
    pincode = db.Column(db.String(6), nullable=False)
    state = db.Column(db.String(100))
    district = db.Column(db.String(100))
    password = db.Column(db.String(60), nullable=False)

    # Relationships
    complaints = db.relationship('Complaint', backref='user', lazy=True)
    sent_contacts = db.relationship('ContactMessage', back_populates='user', cascade="all, delete-orphan")

# ---------------------------
# Complaint Model
# ---------------------------
class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    complaint_text = db.Column(db.Text, nullable=False)
    ipc_section = db.Column(db.String(20))
    ipc_title = db.Column(db.String(200))
    punishment = db.Column(db.String(500))
    status = db.Column(db.String(20), default="Filed")
    date = db.Column(db.DateTime, default=datetime.utcnow)
    doc_path = db.Column(db.String(200))  # e.g., "complaints/xyz.docx"

# ---------------------------
# Lawyer Model
# ---------------------------
class Lawyer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    bar_id = db.Column(db.String(50), unique=True, nullable=False)
    experience = db.Column(db.String(10), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default="Pending")  # Pending / Approved
    date_applied = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    messages = db.relationship('ContactMessage', back_populates='lawyer', cascade="all, delete-orphan")

# ---------------------------
# ContactMessage Model
# ---------------------------
class ContactMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lawyer_id = db.Column(db.Integer, db.ForeignKey('lawyer.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, default="A client is trying to contact you.")
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    lawyer = db.relationship('Lawyer', back_populates='messages')
    user = db.relationship('User', back_populates='sent_contacts')
