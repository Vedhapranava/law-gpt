from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length

# --------------------
# User Registration Form
# --------------------
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    aadhaar = StringField('Aadhaar Number', validators=[DataRequired(), Length(min=12, max=12)])
    pincode = StringField('Pincode', validators=[DataRequired(), Length(min=6, max=6)])
    state = StringField('State')       # Auto-filled
    district = StringField('District') # Auto-filled
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

# --------------------
# Login Form
# --------------------
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# --------------------
# Lawyer Registration Form
# --------------------
class LawyerRegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    bar_id = StringField('Bar Council ID', validators=[DataRequired()])
    experience = StringField('Experience (in years)', validators=[DataRequired()])
    specialization = StringField('Specialization (e.g., Criminal, Civil)', validators=[DataRequired()])
    submit = SubmitField('Apply as Lawyer')
